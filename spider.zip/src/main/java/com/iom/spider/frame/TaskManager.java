package com.iom.spider.frame;

import com.iom.spider.download.DownloadTask;
import com.iom.spider.extract.ExtractTask;
import com.iom.spider.handle.ResultTask;
import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;
import com.iom.spider.queue.CheckableQueue;
import com.iom.spider.queue.DefaultQueue;
import com.iom.spider.queue.Queue;
import com.iom.spider.queue.RepeatableChecker;
import com.iom.spider.utils.MemoryMap;

import java.util.ArrayList;
import java.util.List;

/** 实现build队列, 存储三个队列, 并根据返回数据的不同向不同的队列中append数据; */
public class TaskManager {
    private final static Logger logger = Loggers.getLogger(TaskManager.class);

    private Queue<Task> downloadQueue;
    private Queue<Task> extractQueue;
    private Queue<Task> resultQueue;


    public TaskManager(MemoryMap params) {
        // 队列构建器
        final Queue.Builder queueBuilder;

        final String storePath = "store";

        final List<String> groups = new ArrayList<String>();
        groups.add("test_group");
        final RepeatableChecker checker = new RepeatableChecker(groups, storePath);
        final int capacity = 500;

        /** 实现Queue的Build方法 */
        queueBuilder = new Queue.Builder() {
            @Override
            public <T extends Queue.Element> Queue<T> build(String modelName, MemoryMap fields) {
                return new CheckableQueue<>(new DefaultQueue<>(capacity),checker);
            }
        };

        // 构建队列
        final String downloadQueueName = "SPIDERMAN_DOWNLOAD_TASK";
        this.downloadQueue = queueBuilder.build(downloadQueueName, params);
        logger.debug("创建下载队列(默认)");
        final String extractQueueName ="SPIDERMAN_EXTRACT_TASK";
        this.extractQueue = queueBuilder.build(extractQueueName, params);
        logger.debug("创建解析队列(默认)");
        final String resultQueueName = "SPIDERMAN_RESULT_TASK";
        this.resultQueue = queueBuilder.build(resultQueueName, params);
        logger.debug("创建结果队列(默认)");
        logger.debug("创建TaskManager完成");

    }

    /** 根据worker的返回结果, 向下一个流程添加需要处理的数据 */
    public void append(Task task){
        final String source = task.getSource() == null ? null : task.getSource().getRequest().getUrl();
        if(task instanceof DownloadTask)
            this.downloadQueue.append(task);
        else if (task instanceof ExtractTask)
            this.extractQueue.append(task);
        else if (task instanceof ResultTask)
            this.resultQueue.append(task);
        logger.info("队列中添加任务: "+ task.getKey()+", 来源->"+source);
    }

    public void removeKeys(String group) {
        this.downloadQueue.removeKeys(group);
        this.extractQueue.removeKeys(group);
        this.resultQueue.removeKeys(group);
    }
    public void shutdown() {
        if (this.downloadQueue != null) {
            this.downloadQueue.clear();
        }
        if (this.extractQueue != null) {
            this.extractQueue.clear();
        }
        if (this.resultQueue != null) {
            this.resultQueue.clear();
        }
        logger.debug("退出队列...");
    }



    public Queue<Task> getDownloadQueue() { return this.downloadQueue; }

    public Queue<Task> getExtractQueue() {
        return this.extractQueue;
    }

    public Queue<Task> getResultQueue() {
        return this.resultQueue;
    }



}
