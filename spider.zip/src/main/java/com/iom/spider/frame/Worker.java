package com.iom.spider.frame;

import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;

import java.util.concurrent.CountDownLatch;

public abstract class Worker extends Thread{

    private final String childClassName;     //记录该线程名称
    private final static Logger logger = Loggers.getLogger(Worker.class);
    private WorkerManager manager;
    private WorkerResult result;
    private CountDownLatch countDown;
    private boolean stop;

    public Worker(WorkerManager manager) {
        this.manager = manager;
        this.countDown = new CountDownLatch(1);      //该线程结束后,立即结束
        this.childClassName = getClass().getName();
    }

    //在DownloadWorker中 实现work
    public abstract void work(Task task);

    //执行线程
    public void run() {
        while (true){
            if(stop||this.isInterrupted()) break;

            final Task task;
            try {
                task = manager.takeTask();
            }catch (InternalError error){
                break;
            }catch (Throwable e){
                logger.error("["+this.childClassName+"]Failed to take task from manager!", e);
                continue;
            }
            /** 该线程为常驻线程, 会一直等待有新的任务出现 */
            if (task == null) continue;

            logger.info("["+this.childClassName+"]"+this.getName() + " 获取任务: " + task.getKey());
            try {

                /** 获取到task之后, 立即执行 */
                this.work(task);

            } catch (Throwable e) {
                logger.error("["+this.childClassName+"]"+this.getName() + " 任务失败: " + task.getKey(), e);
                continue;
            }
            logger.info("["+this.childClassName+"]"+this.getName() + " 完成任务: " + task.getKey());
        }
        //执行完毕, 立即计数
        countDown.countDown();
        logger.warn("["+this.childClassName+"]工人["+this.getName() + "]已收工");
    }

    //立即停止线程
    public void stop_work() {
        this.stop = true;
        this.interrupt();
        try {
            this.countDown.await();
        } catch (InterruptedException e) {
        }
    }





    protected WorkerManager getManager() {
        return this.manager;
    }

    protected void setResult(WorkerResult result) {
        this.result = result;
    }

    public WorkerResult getResult() {
        return this.result;
    }








}
