package com.iom.spider.frame;

import java.io.Serializable;

public class WorkerResult implements Serializable {
	
	private static final long serialVersionUID = -7049032302488600282L;
	

	private Task task;
	private Object result;
	
	public WorkerResult(Task task, Object result) {

		this.task = task;
		this.result = result;
	}
	
	public Task getTask() {
		return this.task;
	}
	
	public Object getResult() {
		return this.result;
	}
	
}
