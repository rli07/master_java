package com.iom.spider.frame;


import com.iom.spider.download.Downloader;
import com.iom.spider.queue.Queue;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 用于存储url 与 新发现的url
 */
public abstract class Task extends Queue.AbstractElement {

    private static final long serialVersionUID = 2506296221733528670L;

    /**
     * 请求
     */
    private Downloader.Request request;
    /**
     * 来源
     */
    private Task source;
    /**
     * 当前任务新发现的URL列表
     */
    private Collection<String> links;


    public Task(Task source, String group, Downloader.Request request) {
        super(group);
        this.source = source;
        this.request = request;
        this.links = new HashSet<String>();
    }

    //task可能是一个链表, task中包含task
    public List<Task> getSources() {
        List<Task> list = null;
        Task current = source;
        while (current != null) {
            list.add(current);
            current = current.getSource();
        }
        return list;
    }

    //获取task列表后, 取出该列表中所有url
    public List<String> getSourceUrls() {
        return this.getSources()
                .parallelStream()
                .map(task -> task.getRequest().getUrl())
                .collect(Collectors.toList());
    }

    public Collection<String> getSourceUrlsAndLinks() {
        Collection<String> links = this.getLinks();
        List<String> urls = this.getSourceUrls();
        if (urls != null) {
            links.addAll(urls);
        }
        return links;
    }


    public Collection<String> getLinks() {
        return links;
    }

    public Downloader.Request getRequest() {
        return request;
    }

    public Task getSource() {
        return source;
    }

    public String getSourceUrl() {
        return this.source == null ? null : this.source.getRequest().getUrl();
    }


}
