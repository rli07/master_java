package com.iom.spider.frame;

import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;
import com.iom.spider.utils.Counter;
import com.iom.spider.utils.SpiderException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

public abstract class WorkerManager implements Runnable{
    private final static Logger logger = Loggers.getLogger(WorkerManager.class);

    private final String childClassName;
    private int nWorkers;
    private List<Worker> workers;
    private TaskManager queueManager;
    private CountDownLatch shutdown;

    private Counter counter;
    private List<Listener> listeners;

    public WorkerManager(int nWorkers, TaskManager queueManager, Counter counter) {
        nWorkers = nWorkers > 0 ? nWorkers : 1;
        this.queueManager = queueManager;
        this.nWorkers = nWorkers;
        this.shutdown = new CountDownLatch(1);
        this.childClassName = getClass().getName();
        this.listeners = new ArrayList<>();
        this.counter = counter;
    }

    //接口中的抽象方法, 在调用匿名函数时实现, 完成监听;
    public interface Listener{
        void shouldShutdown();
    }

    public WorkerManager addListener(Listener listener) {
        this.listeners.add(listener);
        return this;
    }

    public Logger getLogger() {
        return logger;
    }
    protected TaskManager getQueueManager() { return queueManager; }
    public abstract Task takeTask() throws InterruptedException;
    protected abstract Worker buildWorker();
    protected abstract void handleResult(WorkerResult workerResult);
    protected abstract void clear();
    public void done(WorkerResult workerResult) {
        this.handleResult(workerResult);
    }

    @Override
    public void run() {
        if (this.queueManager == null) {
            throw new SpiderException(this.childClassName + " 缺少队列管理器");
        }
        logger.debug("[" + this.childClassName + "]我这有" + nWorkers + "个兄弟上班签到");
        workers = new ArrayList<>(nWorkers);
        for (int i = 0; i < nWorkers; i++) {
            final Worker worker = this.buildWorker();
            workers.add(worker);
        }

        this.workers.forEach(w -> w.start());
        this.counter.await();
        logger.debug("[" + this.childClassName + "]我这有" + nWorkers + "个兄弟下班签退");
        this.shutdown();
    }


    public void shutdownAndWait() {
        try {
            this.counter.stop();
            this.shutdown.await();
        } catch (InterruptedException e) {
        }
    }


    private void shutdown() {
        try {
            this.workers.forEach(w -> {
                logger.warn("[" + this.childClassName + "]等待工人[" + w.getName() + "]做收尾工作");
                w.stop_work();//wait for the worker finished the job
            });
        } catch (Throwable e) {
            //ignore
        } finally {
            try {
                this.clear();
            } catch (Throwable e2) {
                e2.printStackTrace();
            }

            logger.debug("[" + this.childClassName + "]退出管理器...");
            // 统计结果
            final String fmt = "[" + this.childClassName + "]统计结果 \r\n 耗时:%sms \r\n 计数:%s \r\n 能力:%s/秒 \r\n 工人数(%s) \r\n";
            final long qps = Math.round((counter.get() * 1.0 / (counter.getCost()) * 1000));
            final String msg = String.format(fmt, counter.getCost(), counter.get(), qps, nWorkers);
            logger.debug(msg);

            listeners.forEach(l -> {
                l.shouldShutdown();
            });

            this.listeners.clear();
            this.shutdown.countDown();
        }
    }


}
