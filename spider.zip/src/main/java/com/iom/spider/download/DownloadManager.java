package com.iom.spider.download;


import com.iom.spider.extract.ExtractTask;
import com.iom.spider.frame.*;
import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;
import com.iom.spider.utils.Counter;
import com.iom.spider.utils.SpiderException;

/**
 * 下载工人驱动器
 */
public class DownloadManager extends WorkerManager {

    private final static Logger logger = Loggers.getLogger(DownloadManager.class);
    private Downloader downloader;
    private long delay;
    private Counter counter;

    public DownloadManager(int nWorkers, TaskManager queueManager, Downloader downloader, long delay, Counter counter) {
        super(nWorkers, queueManager, counter);
        this.downloader = downloader;
        this.delay = delay;
    }

    /**
     * 从队列里获取任务
     */
    @Override
    public Task takeTask() throws InterruptedException {
        return getQueueManager().getDownloadQueue().take();
    }

    /**
     * 构建工人对象
     */
    @Override
    protected Worker buildWorker() {
        return new DownloadWorker(this, downloader, delay);
    }

    /**
     * 处理结果
     */
    @Override
    protected void handleResult(WorkerResult wr) {
        final Object result = wr.getResult();
        final Task task = wr.getTask();
        if (!(result instanceof Downloader.Response)) {
            throw new SpiderException("只接受Downloader.Response类型的结果");
        }
        // 计数器加1
//        long count = getCounter().plus();
        Downloader.Response response = (Downloader.Response) result;
        // 放入解析队列
        getQueueManager().append(new ExtractTask((DownloadTask) task, response));
        //logger.info("下载了第" + count + "个网页: " + response.getRequest().getUrl());
    }

    @Override
    protected void clear() {
        this.downloader.close();
    }
}