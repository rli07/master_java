package com.iom.spider.download;


import com.iom.spider.frame.Task;
import com.iom.spider.frame.Worker;
import com.iom.spider.frame.WorkerManager;
import com.iom.spider.frame.WorkerResult;
import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;
import com.iom.spider.utils.MyUtils;
import com.iom.spider.utils.SpiderException;

import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Set;

public class DownloadWorker extends Worker {

	private Logger logger = Loggers.getLogger(DownloadWorker.class);

	private long delay;
	private Downloader downloader;
	/** 保存已经重定向过的URL地址 */
	private Set<String> redirectedLocations;
	public DownloadWorker(Downloader downloader) {
		this(downloader, 0);
	}
	public DownloadWorker(Downloader downloader, long delay) {
		this(null, downloader, delay);
	}
	public DownloadWorker(WorkerManager manager, Downloader downloader, long delay) {
		super(manager);
		this.downloader = downloader;
		this.redirectedLocations = new HashSet<>();
		this.delay = delay;
	}
	
	public Downloader.Response download(Downloader.Request request) {
		if (delay > 0) {
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
			}
		}
		final Downloader.Response response = this.downloader.doDownload(request);
		if (response == null) {
			return null;
		}
		// 处理异常
		if (response.getException() != null) {
			logger.error("下载["+request.getUrl()+"]失败", response.getException());
		}
		// 处理重定向
		final int statusCode = response.getStatusCode();
		final String location = response.getLocation();
		if (MyUtils.isNotBlank(location) && MyUtils.isIn(statusCode, 301, 302)) {

			// 递归下载  将所有正确url 递推到result;
			if (!redirectedLocations.contains(location)) {
				redirectedLocations.add(location);
				final Downloader.Request newRequest = new Downloader.Request(location);
				return this.download(newRequest);
			}
		}
		if (response.getBody() == null || response.getBody().length == 0) {
			return null;
		}
		// 处理响应体文本编码问题
		String charsetName = response.getCharset();
		if (!MyUtils.isNotBlank(charsetName)) {
			// 获取HTML里面的charset
			charsetName = getCharsetFromBodyStr(new String(response.getBody()));
		}
		if (MyUtils.isNotBlank(charsetName)) {
			response.setCharset(charsetName);
		}
		// 获取响应体文本内容
		final String bodyStr = response.getBodyStr();
		// 若内容为空，结束任务
		if (!MyUtils.isNotBlank(bodyStr)) {
			return null;
		}
		response.setBodyStr(bodyStr);
		return response;
	}

	@Override
	public void work(Task t) {
		if (this.downloader == null) {
			throw new SpiderException("缺少下载器");
		}
		if (t == null) {
			throw new SpiderException("缺少任务对象");
		}
		final DownloadTask task = (DownloadTask)t;
		final Downloader.Request request = task.getRequest();
		final Downloader.Response response = this.download(request);
		if (response == null) {
			return;
		}
		// 告诉经理完成任务，并将结果传递过去
		this.getManager().done(new WorkerResult(task, response));
	}
	
	private String getCharsetFromBodyStr(final String bodyStr) {
		if (!MyUtils.isNotBlank(bodyStr))
			return null;

		
		String html = bodyStr.trim().toLowerCase();
		String s1 = MyUtils.findOneByRegex(html, "(?=<meta ).*charset=.[^/]*");
		if (!MyUtils.isNotBlank(s1))
			return null;

		
		String s2 = MyUtils.findOneByRegex(s1, "(?=charset\\=).[^;/\"']*");
		if (!MyUtils.isNotBlank(s2))
			return null;

		String charsetName = s2.replace("charset=", "");
		return Charset.forName(charsetName).name();
	}
	
}
