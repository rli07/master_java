package com.iom.spider.download.impl;


import com.iom.spider.download.Downloader;
import com.iom.spider.utils.MemoryMap;
import com.iom.spider.utils.MyUtils;
import org.apache.http.*;
import org.apache.http.client.CookieStore;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.*;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;



public class HttpClientDownloader extends Downloader {

	private RequestConfig requestConfig;
	private CloseableHttpClient httpClient;
	private CookieStore cookieStore;
	private Map<String, String> headers;
	
	public HttpClientDownloader() {
		this(new MemoryMap());
	}
	
	public static void main(String[] args) {
//		MemoryMap props = MemoryMap.from(new String[]{"downloader.proxy","10.254.251.230:52460"});
//		HttpClientDownloader downloader = new HttpClientDownloader(props);
//		Request request = new Request("https://www.baidu.com");
//		Response resp = downloader.download(request);
//		System.out.println(resp.getBodyStr());
	}
	
	public HttpClientDownloader(MemoryMap props) {
		RequestConfig.Builder builder = RequestConfig.custom()

	            .setCookieSpec(CookieSpecs.NETSCAPE)
	            .setExpectContinueEnabled(false)
	            .setRedirectsEnabled(props.getBoolean("downloader.redirectsEnabled", false))
	            .setCircularRedirectsAllowed(props.getBoolean("downloader.circularRedirectsAllowed", false))
	            // 设置从连接池获取连接的超时时间
	            .setConnectionRequestTimeout(props.getInt("downloader.connectionRequestTimeout", 1000))
	            // 设置连接远端服务器的超时时间
	            .setConnectTimeout(props.getInt("downloader.connectTimeout", 2000))
	            // 设置从远端服务器上传输数据回来的超时时间
	            .setSocketTimeout(props.getInt("downloader.socketTimeout", 5000))
	            .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.DIGEST))
	            .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.BASIC));

		//实例化RequestConfig
		requestConfig = builder.build();
		
		String proxy = props.getString("downloader.proxy");
		if (MyUtils.isNotBlank(proxy)) {
			builder.setProxy(HttpHost.create(proxy));
		}
		this.cookieStore = new BasicCookieStore();
		this.headers = new HashMap<String, String>();
	    HttpClientBuilder hcb = HttpClients.custom();
		this.httpClient = hcb
				.setUserAgent(props.getString("downloader.userAgent", "Spiderman[http://git.oschina.net/l-weiwei/Spiderman2]"))
				.setDefaultCookieStore(cookieStore)
				.setRetryHandler(new DefaultHttpRequestRetryHandler(0, false))
				.setMaxConnTotal(props.getInt("downloader.maxConnTotal", 1000))
				.setMaxConnPerRoute(props.getInt("downloader.maxConnPerRoute", 500))
				.build();
	}
	

	public Response download(Request request) {

		final Response response = new Response(request);
		final HttpRequestBase req;
		HttpResponse resp = null;

		try {
			if (MyUtils.HTTP_POST.equals(request.getMethod())) {
				req = new HttpPost(request.getUrl());
			} else {
				req = new HttpGet(request.getUrl());
			}
			
			RequestConfig reqCfg = buildRequestConfig(new MemoryMap());
			req.setConfig(reqCfg);
			
			headers.forEach((k,v) -> req.addHeader(k, v));
//			if (request.getHeaders() != null) {
//				request.getHeaders().parallelStream().forEach(h -> req.addHeader(h.getName(), h.getValue()));
//			}
//			if (request.getCookies() != null) {
//				request.getCookies().parallelStream().forEach(c -> keepCookie(c));
//			}
			HttpClientContext ctx = HttpClientContext.create();
			resp = this.httpClient.execute(req, ctx);
			// get status
			StatusLine statusLine = resp.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			String statusDesc = statusLine.getReasonPhrase();
			response.setStatusCode(statusCode);
//			response.setStatusDesc(statusDesc);
			// cookies
			CookieStore cs = ctx.getCookieStore();
//			cs.getCookies().parallelStream()
//				.map(c -> new Cookie(c.getName(), c.getValue(), c.getDomain(), c.getPath(), c.getExpiryDate(), c.isSecure()))
//				.forEach(c -> keepCookie(c));
			// get redirect location
			org.apache.http.Header locationHeader = resp.getFirstHeader("Location");
			if (locationHeader != null && (statusCode == HttpStatus.SC_MOVED_PERMANENTLY || statusCode == HttpStatus.SC_MOVED_TEMPORARILY)){
				response.setLocation(locationHeader.getValue());
				System.out.println("locationHeader.getValue()"+locationHeader.getValue());
			}

			
		    // entity
			HttpEntity entity = resp.getEntity();
			// content type and charset
			ContentType contentType = ContentType.getOrDefault(entity);
			Charset charset = contentType.getCharset();
			response.setCharset(charset == null ? null : charset.name());
//			response.setMimeType(contentType.getMimeType());
			// body
			byte[] body = EntityUtils.toByteArray(entity);
			/** 得到html */
			response.setBody(body);
			response.strFromByte(response.getBody());
			resp = null;
		} catch (Throwable e) {
//			response.setException(e);
		} finally {  
            try {  
                if (resp != null) {  
                    resp.getEntity().getContent().close();  
                }  
            } catch (Throwable e) {  
            } 
        }  
		
		return response;
	}

	private RequestConfig buildRequestConfig(MemoryMap request) {
		RequestConfig.Builder builder = RequestConfig.copy(requestConfig);
		MemoryMap reqProps = request;
		if (reqProps.containsKey("socketTimeout")) {
			builder.setSocketTimeout(reqProps.getInt("socketTimeout"));
		}
		if (reqProps.containsKey("connectTimeout")) {
			builder.setConnectTimeout(reqProps.getInt("connectTimeout"));
		}
		if (reqProps.containsKey("connectionRequestTimeout")) {
			builder.setConnectionRequestTimeout(reqProps.getInt("connectionRequestTimeout"));
		}
		if (reqProps.containsKey("redirectsEnabled")) {
			builder.setRedirectsEnabled(reqProps.getBoolean("redirectsEnabled"));
		}
		if (reqProps.containsKey("circularRedirectsAllowed")) {
			builder.setCircularRedirectsAllowed(reqProps.getBoolean("circularRedirectsAllowed"));
		}
		RequestConfig reqCfg = builder.build();
		return reqCfg;
	}

	
	public void close() {
		try {
			this.httpClient.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}