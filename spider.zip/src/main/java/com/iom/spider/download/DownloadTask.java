package com.iom.spider.download;

import com.iom.spider.extract.ExtractTask;
import com.iom.spider.frame.Task;

public class DownloadTask extends Task {

    private static final long serialVersionUID = 6126003860229810350L;

    public DownloadTask(ExtractTask source, String group, Downloader.Request request) {
        super(source, group, request);
    }

    public DownloadTask( String group, Downloader.Request request) {
        super(null, group, request);
    }

    @Override
    public String getKey() {
        return this.getRequest().getUrl();
    }
}
