package com.iom.spider.download;

import com.iom.spider.utils.MyUtils;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;

public abstract class Downloader {


    public abstract Response download(Request request);
    public abstract void close();

    //不允许被覆盖
    final Response doDownload(Request request) {
        //this.listener.beforeDownload(this, request);
        final Response response = this.download(request);
        //this.listener.afterDownload(this, response);
        return response;
    }


    public static class Request implements Serializable {
        private static final long serialVersionUID = -5271854259417049190L;
        private String url;
        private String method;

        public Request(String url, String method) {
            this.url = url;
            this.method = method;
        }

        public Request(String url) {
            this.url = url;
            this.method = MyUtils.HTTP_GET;
        }


        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getMethod() {
            return method;
        }

        public void setMethod(String method) {
            this.method = method;
        }
    }

    public static class Response implements Serializable {
        private static final long serialVersionUID = -9068800067277456934L;
        private Request request;
        private int statusCode;
        private String charset;
        private String location;
        private byte[] body;
        private String bodyStr;// 默认是null
        private Throwable exception;

        public Response() {
        }

        public Response(Request request) {
            this.request = request;
        }

        public Response(Request request, int statusCode) {
            this.request = request;
            this.statusCode = statusCode;
        }

        public String strFromByte(byte[] body) throws UnsupportedEncodingException {
            if (bodyStr == null && body != null)
                this.bodyStr = MyUtils.StrFromByte(body, charset);
            return bodyStr;
        }

        public Request getRequest() {
            return request;
        }

        public void setRequest(Request request) {
            this.request = request;
        }

        public int getStatusCode() {
            return statusCode;
        }

        public void setStatusCode(int statusCode) {
            this.statusCode = statusCode;
        }

        public String getCharset() {
            return charset;
        }

        public void setCharset(String charset) {
            this.charset = charset;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        public byte[] getBody() {
            return body;
        }

        public void setBody(byte[] body) {
            this.body = body;
        }

        public String getBodyStr() {
            return bodyStr;
        }

        public void setBodyStr(String bodyStr) {
            this.bodyStr = bodyStr;
        }

        public Throwable getException() {
            return exception;
        }

        public void setException(Throwable exception) {
            this.exception = exception;
        }
    }


}










