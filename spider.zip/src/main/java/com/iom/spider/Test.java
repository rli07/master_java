package com.iom.spider;

import com.alibaba.fastjson.JSON;
import com.iom.spider.download.Downloader;
import com.iom.spider.download.impl.HttpClientDownloader;
import com.iom.spider.extract.extractor.Extractor;
import com.iom.spider.extract.extractor.impl.HtmlCleanerExtractor;
import com.iom.spider.extract.schema.Model;
import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;

public class Test {
    public static void main(String[] args) {
        Logger logger = Loggers.getLogger(Test.class);

        Downloader downloader = new HttpClientDownloader();
        String url = "http://blog.39.net/ArtTop_2_3.html";
        String method = "GET";
        Downloader.Request request = new Downloader.Request(url,method);
        Downloader.Response response =  downloader.download(request);
        String html = response.getBodyStr();
        //System.out.println(html);

        Model model = new Model("test");
        model.addField("link").set("xpath", "//*[@class='total_rank']//a").set("attr","href").set("isArray", true);

        //System.out.println("xpath   "+model.get("xpath"));
        /** models.getString()  因为都是从models.addFileds() .set() 是添加进Fileds 而不是直接加进Models里 */
        Extractor extractor = new HtmlCleanerExtractor(html);
        extractor.addModel(model);


        extractor.extract(new Extractor.Callback() {
            @Override
            public void onModelExtracted(ModelEntry entry) {
                //System.out.println(entry.getIdx());
                System.out.println(JSON.toJSONString(entry.getFields(),true));
            }

            @Override
            public void onFieldExtracted(FieldEntry entry) {

            }
        });

    }
}
