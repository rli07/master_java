package com.iom.spider;

import com.iom.spider.download.DownloadManager;
import com.iom.spider.download.DownloadTask;
import com.iom.spider.download.Downloader;
import com.iom.spider.download.impl.HttpClientDownloader;
import com.iom.spider.extract.ExtractTask;
import com.iom.spider.extract.extractor.Extractor;
import com.iom.spider.extract.extractor.impl.HtmlCleanerExtractor;
import com.iom.spider.extract.schema.Model;
import com.iom.spider.frame.Task;
import com.iom.spider.frame.TaskManager;
import com.iom.spider.frame.WorkerManager;
import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;
import com.iom.spider.utils.Counter;
import com.iom.spider.utils.MemoryMap;

public class Test2 {
    public static void main(String[] args) throws InterruptedException {
        Logger logger = Loggers.getLogger(Test2.class);

        Downloader downloader = new HttpClientDownloader();
        String url = "http://blog.39.net/ArtTop_2_5.html";
        String method = "GET";
        Downloader.Request request = new Downloader.Request(url,method);
//        Downloader.Response response =  downloader.download(request);
//        String html = response.getBodyStr();
//        System.out.println(html);


        /** 构建框架 */
        TaskManager taskManager = new TaskManager(new MemoryMap());
        Task download = new DownloadTask("test_group", request);
        taskManager.append(download);
        Downloader downloader1 = new HttpClientDownloader();
        //创建计数器
        Counter counter = new Counter(1,10);

        WorkerManager workerManager1 = new DownloadManager(1,taskManager,downloader1,10,counter);

        //为WorkerManager添加监听器
        workerManager1.addListener(()->{
            counter.plus();
        });

        Thread t = new Thread(workerManager1);
        t.start();
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
        }

        ExtractTask t2 = (ExtractTask)taskManager.getExtractQueue().take();
        String html = t2.getResponse().getBodyStr();

        //System.out.println(html);






        Model model = new Model("test");
        model.addField("link").set("xpath", "//*[@class='total_rank']//a").set("attr","href").set("isArray", true);

        //System.out.println("xpath   "+model.get("xpath"));
        /** models.getString()  因为都是从models.addFileds() .set() 是添加进Fileds 而不是直接加进Models里 */
        Extractor extractor = new HtmlCleanerExtractor(html);
        extractor.addModel(model);


        extractor.extract(new Extractor.Callback() {
            @Override
            public void onModelExtracted(ModelEntry entry) {
                //System.out.println(entry.getIdx());
                //System.out.println(JSON.toJSONString(entry.getFields(),true));
            }

            @Override
            public void onFieldExtracted(FieldEntry entry) {

            }
        });

    }
}
