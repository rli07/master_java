package com.iom.spider.handle;

import com.iom.spider.download.Downloader;
import com.iom.spider.frame.Task;

public class ResultTask extends Task {
    public ResultTask(Task source, String group, Downloader.Request request) {
        super(source, group, request);
    }

    @Override
    public String getKey() {
        return null;
    }
}
