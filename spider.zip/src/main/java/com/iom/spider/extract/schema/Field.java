package com.iom.spider.extract.schema;

import com.iom.spider.utils.MemoryMap;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class Field extends MemoryMap {

    private static final Logger logger = Logger.getLogger(Field.class.getName());

    private static final long serialVersionUID = 7148432045433277575L;

    private String page;
    private String model;
    private String name;

    private List<Field> fields;

    public Field(String page, String model, String name) {
        this.page = page;
        this.model = model;
        this.name = name;
        this.fields = new ArrayList<>();
    }

    public String getPage() {
        return this.page;
    }

    public String getModel() {
        return this.model;
    }

    public List<Field> getFields() {
        return this.fields;
    }

    public Field addField(String name) {
        Field field = new Field(page, this.name, name);
        this.fields.add(field);
        return field;
    }

    public Model toModel() {
        return new Model(page, name, fields).set("isAutoExtractAttrs", true);
    }

    public String getName() {
        return this.name;
    }

    public Field set(String k, Object v) {
        this.put(k, v);
        return this;
    }


    public String toString() {
        return "Field [page=" + page + ", model=" + model + ", name=" + name + "]";
    }

}
