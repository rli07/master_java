package com.iom.spider.extract;

import com.iom.spider.download.DownloadTask;
import com.iom.spider.download.Downloader;
import com.iom.spider.frame.Task;

public class ExtractTask extends Task {

    private static final long serialVersionUID = 7914255707423166114L;

    private Downloader.Response response;

    public ExtractTask(Downloader.Response response) {
        super( null, null, response.getRequest());
        this.response = response;
    }

    public ExtractTask(DownloadTask task, Downloader.Response response) {
        super( task.getSource(), task.getGroup(), response.getRequest());
        this.response = response;
    }
    public Downloader.Response getResponse() {
        return this.response;
    }

    @Override
    public String getKey() {
        return null;
    }
}
