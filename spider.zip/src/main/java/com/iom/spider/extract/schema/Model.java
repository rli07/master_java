package com.iom.spider.extract.schema;


import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;
import com.iom.spider.utils.MemoryMap;

import java.util.ArrayList;
import java.util.List;


public class Model extends MemoryMap {

    private static final Logger logger = Loggers.getLogger(Model.class);

    private static final long serialVersionUID = 17497943540212548L;

    private String page;
    private String name;
    private List<Field> fields;

    public Model(String page, String name, List<Field> fields) {
        this.page = page;
        this.name = name;
        this.fields = fields;
    }

    public Model(String name) {
        this(null, name, new ArrayList<>());
        logger.info("创建模型[" + name + "]");
    }

    public Model(String page, String name) {
        this(page, name, new ArrayList<>());
    }

    public String getPage() {
        return this.page;
    }

    public String getName() {
        return this.name;
    }

    public Model set(String key, Object value) {
        this.put(key, value);
        return this;
    }

    public Field addField(String name) {
        if (name == null) {
            throw new NullPointerException("addField parameter[name] is null");
        }
        Field field = new Field(page, this.name, name);
        this.fields.add(field);
        logger.info("添加字段配置: " + field);
        return field;
    }

    public List<Field> getFields() {
        return this.fields;
    }



    public String toString() {
        return "Model [page=" + page + ", name=" + name + ", fields=" + fields + "]";
    }

}
