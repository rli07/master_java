package com.iom.spider.extract.extractor;

import com.iom.spider.utils.MemoryMap;
import com.iom.spider.utils.MyUtils;
import com.iom.spider.extract.extractor.impl.HtmlCleanerExtractor;
import com.iom.spider.extract.schema.Field;
import com.iom.spider.extract.schema.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 抽象XPath解析 , 所有支持XPath的解析 都要继承此类
 */
public abstract class AbstractXPathExtractor extends Extractor {

//    protected AbstractXPathExtractor(ExtractTask task, String page, Model... models) {
//        super(task, page, models);
//    }


    public AbstractXPathExtractor(String page, Model... models) {
        super(page, models);
    }

    protected abstract Object getDoc();  //返回TagNode

    protected abstract List<Object> extractModel(Object doc, String modelXpath);

    protected abstract List<Object> extractField(Object model, Field field, String defaultValue,
                                                 String xpath, String attr, boolean isFromDoc, boolean isSerialize);

    protected abstract Map<String, String> extractAttributes(Object node);

    public void extract(Callback callback) {
        List<Model> models = getModels();   //返回Extractor中的List<Model>
        if (!MyUtils.isNotEmpty(models)) {
            return;
            //throw new Spiderman.Exception("请添加抽取模型配置");
        }

        models.forEach(model -> {

            final Object doc = getDoc(); //获得TagNode, 也就是将html完全解析;
            List<Object> mNodes = new ArrayList<>();

            mNodes.add(doc);

            for (int i = 0; i < mNodes.size(); i++) {
                Object mNode = mNodes.get(i);
                //Map<field.getName(), Callback.FieldEntry>
                final MemoryMap fields = this.extractModel(mNode, model, callback);
                // 通知回调
                callback.onModelExtracted(new Callback.ModelEntry(i, model, fields));
            }
        });
    }

    private MemoryMap extractModel(Object mNode, Model model, Callback callback) {
        final MemoryMap fields = new MemoryMap();
        if (model.getBoolean("isAutoExtractAttrs", false)) {
            // extract all attributes
            Map<String, String> attrs = this.extractAttributes(mNode);
            if (attrs != null) {
                attrs.forEach((k, v) -> {
                    fields.put(k, v);
                });
            }
        }
        model.getFields().forEach(field -> {
            final String defaultValue = field.getString("value", null);
            final String xpath = field.getString("xpath", ".");
            final String attr = field.getString("attribute", field.getString("attr"));
            final boolean isSerialize = field.getBoolean("isSerialize", false);
            final boolean isFromDoc = field.getBoolean("isFromDoc", false);
            final boolean isAutoExtractAttrs = field.getBoolean("isAutoExtractAttrs", false);

            // 抽取字段
            List<Object> values = this.extractField(mNode, field, defaultValue, xpath, attr, isFromDoc, isSerialize);

            if (!MyUtils.isNotEmpty(values)) {
                return;
            }

            // 若字段包含子字段，则进入递归抽取
            if (isAutoExtractAttrs || MyUtils.isNotEmpty(field.getFields())) {
                List<Object> subValues = new ArrayList<>();
                values.forEach(node -> {
                    MemoryMap _fields = this.extractModel(node, field.toModel(), callback);
                    subValues.add(_fields);
                });
                values = subValues;
            }

            final boolean isArray = field.getBoolean("isArray", false);
            final Callback.FieldEntry entry = new Callback.FieldEntry(field, values);
            entry.setData(isArray ? values : values.get(0));
            if (MyUtils.isNotEmpty(field.getFields()) || !(this instanceof HtmlCleanerExtractor)) {
                callback.onFieldExtracted(entry); //进行字段过滤和新URL入队列
            }
            fields.put(field.getName(), entry.getData());
        });
        return fields;
    }

}
