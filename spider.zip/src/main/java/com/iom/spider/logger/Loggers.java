package com.iom.spider.logger;


import com.iom.spider.utils.MyUtils;

public class Loggers {


	public final static Logger getLogger(Class<?> clazz) {
		String level = MyUtils.props_get("logger.level","OFF");
		return new ConsoleLogger(clazz, level);
	}
	
}
