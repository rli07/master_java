package com.iom.spider.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyUtils {

    public final static String HTTP_GET = "GET";
    public final static String HTTP_POST = "POST";

    public static boolean isNotBlank(String input) {
        return null != input && input.trim().length() != 0;
    }

    public static boolean isNotEmpty(Collection collection) {
        return collection != null && collection.size() != 0;
    }

    //二进制html 转成 String
    public static String StrFromByte(byte[] bytes,String charset) throws UnsupportedEncodingException {
        return new String(bytes,charset);
    }

    //获取当前时间
    public static String fromNow(){
        String format = "yyyy-MM-dd HH:mm:ss";
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(new Date());
    }

    //获取properties配置
    public static String props_get(String key, String default_){
        InputStream in = null;
        String value = null;
        try {
            in=MyUtils.class.getResourceAsStream("/log.properties");
            Properties props = new Properties();
            props.load(in);
            value = props.getProperty(key);
        }catch (IOException e){
            e.printStackTrace();
        }
        return value==null?default_:value;
    }

    //判断状态码
    public static boolean isIn(int targe, int...params){
        for(int i:params){
            if(i==targe) return true;
        }
        return false;
    }

    public static String findOneByRegex(String input, String regex) {
        List<String> tmp = findByRegex(input, regex);
        return isNotEmpty(tmp) ? tmp.get(0):null ;
    }

    public static List<String> findByRegex(String input, String regex) {
        List<String> result = new ArrayList<String>();
        Pattern p = Pattern.compile(regex, Pattern.DOTALL);
        Matcher m = p.matcher(input);
        while (m.find()) {
            result.add(m.group());
        }

        if (result.isEmpty())
            return null;

        return result;
    }


}
