package com.iom.spider.utils;

import java.util.HashMap;

public class MemoryMap extends HashMap<String,Object> {
   public  Boolean getBoolean(String s, boolean default_ ){return this.getBoolean(s)==null?default_:this.getBoolean(s);}
    public  Boolean getBoolean(String s ){return (Boolean) this.get(s);}
    public  int getInt(String s, int default_ ){return this.getInt(s)<0?default_:this.getInt(s);}
    public  int getInt(String s){return this.get(s)!=null?(int)this.get(s):0;}
    public  String getString(String s){return (String) this.get((Object)s);}
    public  String getString(String s,String default_){return this.getString(s)==null?default_:this.getString(s);}


}
