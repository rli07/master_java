package com.iom.spider.utils;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public class Counter {

    private AtomicLong count;   //乐观锁计数

    private int limit;         //计数最大限制

    private CountDownLatch countDown;

    private long timeout;      //等待超时
    private long start;
    private long end;

    public Counter(int limit, long timeout) {
        this.limit = limit;
        this.count = new AtomicLong(1);
        this.countDown = new CountDownLatch(limit<=0?1:limit);
        this.timeout = timeout;
        this.start = System.currentTimeMillis();
    }

    public long plus(){
        if(limit>0)
            countDown.countDown();
        return count.addAndGet(1);
    }

    /**
     * 供外界主动调用
     */
    public void stop() {
        final int c = limit > 0 ? limit : 1;
        for (int i = 0; i < c; i++) {
            this.countDown.countDown();
        }
        this.end = System.currentTimeMillis();
    }

    /** 当线程被阻塞时,应设置超时时间, 避免死锁; */
    public void await() {
        try {
            if (timeout > 0) {
                this.countDown.await(timeout, TimeUnit.MILLISECONDS);
            } else {
                this.countDown.await();
            }
        } catch (InterruptedException e) {
            //ignore
        }
        this.end = System.currentTimeMillis();
    }

    public int getLimit() {
        return this.limit;
    }

    public boolean isTimeout() {
        return this.getCost() >= this.timeout;
    }

    public long get() {
        return this.count.get();
    }

    public long getCost() {
        final long cost = this.end - this.start;
        return cost;
    }

    public String toString() {
        if (limit > 0) {
            return get() + "/" + limit;
        }
        return get() + "";
    }




























}
