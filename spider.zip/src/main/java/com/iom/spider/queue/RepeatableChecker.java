package com.iom.spider.queue;


import com.iom.spider.logger.Logger;
import com.iom.spider.logger.Loggers;
import com.iom.spider.queue.store.BDbStore;
import com.iom.spider.queue.store.KVStore;
import com.iom.spider.utils.MyUtils;

import java.io.File;
import java.util.List;


public class RepeatableChecker implements CheckableQueue.Checker {

	private final static Logger logger = Loggers.getLogger(RepeatableChecker.class);
	/** 去重需要用到存储 */
	private KVStore store;
	
	public RepeatableChecker(List<String> groups, String storePath) {
		final File file = new File(storePath);
		file.mkdirs();
		this.store = new BDbStore(file, groups.toArray(new String[]{}));
		logger.debug(RepeatableChecker.class.getName()+" 构建KVStore[names="+groups+", file="+file.getAbsolutePath()+"]存储对象, 使用BDb实现");
	}
	
	public boolean check(Queue.Element e) {
		if (e instanceof Queue.AbstractElement) {
			// 检查重复
			final Queue.AbstractElement ae = ((Queue.AbstractElement)e);
			final String group = ae.getGroup();
			final String key = ae.getKey();
			if (!MyUtils.isNotBlank(key) || !MyUtils.isNotBlank(group)) {
				return true;
			}
			
			if (store.contains(group, key)) {
				// key重复了
				logger.warn("队列元素重复[group="+group+", key="+key+"]");
				return false;
			}
			// 将key存储起来
			this.store.put(group, key, key.getBytes());

		}
		return true;
	}
	
	public void clear() {
		this.store.close();
	}
	
	public void removeKeys(String group) {
		this.store.removeKeys(group);
	}

}