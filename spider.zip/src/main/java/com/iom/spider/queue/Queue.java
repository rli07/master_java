package com.iom.spider.queue;

import com.iom.spider.utils.MemoryMap;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public interface Queue<E> {

     E take() throws InterruptedException;

     void append(E element);    //增加Model

     void append(byte[] data); //增加Html

     void clear();

     void removeKeys(String group);

     /** Element存储Html */
     abstract class Element implements Serializable {
          private static final long serialVersionUID = -4673461723487153923L;
          protected byte[] body;
          public void setBody(byte[] body) {
               this.body = body;
          }
          public byte[] getBody() {
               return this.body;
          }
     }
     /** AbstractElement存储Model分组, 以及Element的Html  */
     abstract class AbstractElement extends Element{
          private static final long serialVersionUID = 5693140072005182715L;
          private Map<String, Object> headers;

          public AbstractElement(String group) {
               this.headers = new HashMap<String, Object>();
               this.headers.put("group", group);
          }
          public abstract String getKey();
          public String getGroup() {
               return (String)this.headers.get("group");
          }
          public void addHeader(String name, Object value) {
               this.headers.put(name, value);
          }
          public Object getHeader(String name) {
               return this.headers.get(name);
          }

     }

     /** 通过Modle创建队列 */
     interface Builder{
          <T extends Element> Queue<T> build(String modelName, MemoryMap fields);
     }


}
