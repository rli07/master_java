package com.iom.spider.queue;


/** 如果队列中存储的是url 而不是html, 需要对url进行去重处理 */
public class CheckableQueue<E extends Queue.Element> implements Queue<E> {

    //该类只是将队列与检查进行整合,具体实现还需要 阻塞队列 与 检查类;
    private Queue<E> queue;
    private CheckableQueue.Checker checker;    //RepeatableChecker.java

    @Override
    public E take() throws InterruptedException {
        return queue.take();
    }

    @Override
    public void append(E e) {
        if(checker.check(e))
            queue.append(e);
    }

    @Override
    public void append(byte[] data) {
        // url队列不需要添加html
    }

    @Override
    public void clear() {
        queue.clear();
        checker.clear();
    }

    @Override
    public void removeKeys(String group) {
        queue.removeKeys(group);
        checker.removeKeys(group);
    }

    public CheckableQueue(Queue<E> queue, Checker checker) {
        if (checker == null) {
            throw new NullPointerException("Checker");
        }
        if (queue == null) {
            throw new NullPointerException("Queue");
        }
        this.queue = queue;
        this.checker = checker;
    }

    interface Checker{
        boolean check(Element e);
        void clear();
        void removeKeys(String group);
    }
}
